package com.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks{
	
	public WebDriver driver = null;
	public String URL = "https://www.dbs.com.sg/index/default.page";
	
	@Before
	public void launchBrowser() {
		String path = System.getProperty("user.dir");		
		System.setProperty("webdriver.chrome.driver", path+"/drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get(URL);

	}
	
	@After
	public void closeBrowser() {
		if(driver != null)
			driver.close();
		
	}

	
	
	
}
