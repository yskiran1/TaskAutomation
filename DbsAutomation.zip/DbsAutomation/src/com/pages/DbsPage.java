package com.pages;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DbsPage {

	public static WebDriver driver;
	public int defaultWaitTime = 10;
	public Set<String> awardNames;
	public Map<String, String> captionsMap;
	
	DbsPage(){
		
	}

	// Page Elements
	@FindBy(how = How.XPATH, using = "//a[text()='DBS']")
	private WebElement dbsGroup;

	@FindBy(how = How.XPATH, using = "//a[contains(@href, 'splitter-portraits-of-purpose')]")
	private WebElement learnMore;

	@FindBy(how = How.XPATH, using = "//div[@class='navbar-links-left']//a[contains(text(),'Sustainability')]")
	private WebElement sustainability;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Creating Social Impact')]")
	private WebElement creatingSocialImpact;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'DBS Stronger Together Fund')]")
	private WebElement dbsStrongerTogetherFund;

	@FindBy(how = How.XPATH, using = "//a[@class='nav-link hasDevice'][contains(text(),'Singapore')]")
	private WebElement linkSingapore;

	@FindBy(how = How.XPATH, using = "//div[@class='navbar-links-left']//a[contains(text(),'About')]")
	private WebElement linkAbout;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Who We Are')]")
	private WebElement whoWeAre;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Our Awards & Accolades')]")
	private WebElement ourAwardsAccolades;

	@FindBy(how = How.XPATH, using = "//h3/strong")
	private List<WebElement> awards;

	@FindBy(how = How.XPATH, using = "//div[@class='rich-text-box']//div//table/tbody/tr[1]/td")
	private List<WebElement> dbsTableColumns;

	@FindBy(how = How.XPATH, using = "//div[@class='rich-text-box']//div//table/tbody//tr")
	private List<WebElement> dbsTableRows;

	@FindBy(how = How.XPATH, using = "//div[@class='rich-text-box']//div//table/tbody//tr")
	private WebElement dbsTableCell;

	@FindBy(how = How.XPATH, using = "//h3/strong")
	public WebElement caption;

	public Map<String, String> getCaptionNames() {
		captionsMap = new HashMap<String, String>();
		if (awards == null && awards.size() < 0)
			getUniqueAwards();
		
		for (String awardName : awardNames) {
			List<WebElement> ls = caption
					.findElements(By.xpath("//h3/strong[contains(text(),'" + awardName + "')]/following::p[1]"));
			for (WebElement caption : ls) {
				if (!captionsMap.containsKey(awardName))
					captionsMap.put(awardName, caption.getText());
				else {
					String val = captionsMap.get(awardName);
					captionsMap.put(awardName, val + "," + caption.getText());
				}
			}
		}
		return captionsMap;

	}

	public WebElement getTableCell() {
		return dbsTableCell;
	}

	public void clickLearnMore() {
		learnMore.click();
	}

	public int noOfAwards() {
		if (awards == null && awards.size() < 0)
			getUniqueAwards();
		
		return awards.size();
	}

//	Map<String, String> captionsMap = new HashMap<>();
//	
//	public static void main(String[] args) {
//		DbsPage dbs = new DbsPage();
//		 //captionsMap = new HashMap<>();
//		dbs.captionsMap.put("A", "A1");
//		dbs.captionsMap.put("B", "B1");
//		dbs.captionsMap.put("C", "C1, C2");
//		dbs.captionsMap.put("D", "D3");
//		
//		dbs.validateCaptions("A1", "asdf");
//		dbs.validateCaptions("D", "D3");
//		dbs.validateCaptions("C", "C2");
//		dbs.validateCaptions("C", "C3");
//		
//	}
	
	public void validateCaptions(String expectedKey, String expectedCaption) {
		if(captionsMap == null) 
			getCaptionNames();
		
		String actualCaptionNames = captionsMap.get(expectedKey);
		if(actualCaptionNames == null) {
			System.out.println("Invalid Key name and Test case FAIL.");
		}else if(actualCaptionNames.contains(expectedCaption) ) {
			System.out.println("Key exists and Test case Pass.");
		}else if(!actualCaptionNames.contains(expectedCaption) ) {
			System.out.println("Key exists and Test case Fail as expectedCaption NOT in actualCaption.");
		}
		
	}
	public Set<String> getUniqueAwards() {
		awardNames = new HashSet<>();
		for (WebElement award : awards) {
			String awardName = award.getText();
			awardNames.add(awardName);

		}
		return awardNames;
	}

	public void waitForPageLoad() {
		driver.manage().timeouts().implicitlyWait(defaultWaitTime, TimeUnit.SECONDS);
	}

	public void waitForPageLoad(int seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}

	public void moveToDbsGroupElement() {
		Actions act = new Actions(driver);
		act.moveToElement(dbsGroup);
	}

	public DbsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void clickOnSustainability() {
		sustainability.click();

	}

	public void clickOnCreatingSocialImpact() {
		creatingSocialImpact.click();

	}

	public void clickOnDbsStrongerTogetherFund() {
		dbsStrongerTogetherFund.click();

	}

	public void clickOnLinkSingapore() {
		linkSingapore.click();

	}

	public void clickOnLinkAbout() {
		linkAbout.click();

	}

	public void clickOnWhoWeAre() {
		whoWeAre.click();
	}

	public void clickOnOurAwardsAccolades() {
		ourAwardsAccolades.click();
	}

	public List<WebElement> getTableColumns() {
		return dbsTableColumns;
	}

	public List<WebElement> getTableRows() {
		return dbsTableRows;
	}
}
