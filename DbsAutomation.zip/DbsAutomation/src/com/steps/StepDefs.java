package com.steps;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.DbsPage;

import io.cucumber.java8.En;

public class StepDefs implements En {

	public static WebDriver driver = null;
	public String URL = "https://www.dbs.com.sg/index/default.page";
	public DbsPage dbsPage;

	public StepDefs() {

		Given("I want to visit URL", () -> {
			String path = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", path + "/drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(URL);
			driver.manage().window().maximize();

			// Page Init
			dbsPage = new DbsPage(driver);

			// PageFactory Methods
			dbsPage.moveToDbsGroupElement();
			dbsPage.waitForPageLoad(3);

		});

		When("I click on LearnMore action and other links", () -> {
			dbsPage.clickLearnMore();
			dbsPage.clickOnSustainability();
			dbsPage.waitForPageLoad();
			dbsPage.clickOnCreatingSocialImpact();
			dbsPage.waitForPageLoad(15);
			dbsPage.clickOnDbsStrongerTogetherFund();
			dbsPage.waitForPageLoad(5);

		});

		When("I click on Singapore from left panel", () -> {
			dbsPage.clickOnLinkSingapore();
			dbsPage.waitForPageLoad(5);
		});

		Then("I am able to see DBS table data", () -> {
			List<WebElement> col = dbsPage.getTableColumns();
			List<WebElement> row = dbsPage.getTableRows();
			if (col.size() > 0 && row.size() > 0) {
				System.out.println("I am able to see DBS table data");
			}
		});

		Then("I am saving data to excel", () -> {
			saveToExcel();
		});

		Then("I close the browser", () -> {
			if (driver != null) {
				driver.close();
				System.out.println("driver object closed successfully");
			}
		});

		When("I click on About and other links", () -> {
			dbsPage.waitForPageLoad();
			dbsPage.clickOnLinkAbout();
			dbsPage.waitForPageLoad();
			dbsPage.clickOnWhoWeAre();
			dbsPage.waitForPageLoad();
			dbsPage.clickOnOurAwardsAccolades();
			System.out.println("Number of awards:" + dbsPage.noOfAwards());

		});

		Then("I am able to Awards page", () -> {
			if (dbsPage.awardNames == null)
				dbsPage.getUniqueAwards();

			if (dbsPage.awardNames.size() > 0) {
				System.out.println("we are navigated to awards page successfully");
			}

		});

		Then("I am verifying caption names", () -> {
			// Map<String, String> captionsData = dbsPage.getCaptionNames();

			String input = "The Banker";
			String expectedCaption = "Bank of the Year 2018";

			String input2 = "A World First";
			String expectedCaption2 = "Euromoney";

			String input3 = "Global Finance";
			String expectedCaption3 = "Best Bank in the World 2018";

			String input4 = "Euromoney";
			String expectedCaption4 = "Awards For Excellence";

			String input5 = "Global Finance";
			String expectedCaption5 = "World's Best Banks";
			String input6 = "Global Finance";
			String expectedCaption6 = "World's Best Investment Banks and Derivatives Providers";

			dbsPage.validateCaptions(input2, expectedCaption2);
			dbsPage.validateCaptions(input, expectedCaption);
			dbsPage.validateCaptions(input3, expectedCaption3);
			dbsPage.validateCaptions(input4, expectedCaption4);
			dbsPage.validateCaptions(input5, expectedCaption5);
			dbsPage.validateCaptions(input6, expectedCaption6);

			/*
			 * captionsData.forEach((k,v) -> {
			 * 
			 * if(k.equalsIgnoreCase(input) && v.contains(expectedCaption)) {
			 * System.out.println("Test case PASS for -> "+input); }
			 * if(k.equalsIgnoreCase(input2) || v.contains(expectedCaption2)) {
			 * System.out.println("Test case Fail for -> "+input2); }
			 * if(k.equalsIgnoreCase(input3) && v.contains(expectedCaption3)) {
			 * System.out.println("Test case PASS for -> "+input3); }
			 * if(k.equalsIgnoreCase(input4) && v.contains(expectedCaption4)) {
			 * System.out.println("Test case PASS for -> "+input4); }
			 * if(k.equalsIgnoreCase(input5) && v.contains(expectedCaption5)) {
			 * System.out.println("Test case PASS for -> "+input5); }
			 * if(k.equalsIgnoreCase(input6) && v.contains(expectedCaption6)) {
			 * System.out.println("Test case PASS for -> "+input6); } //
			 * System.out.println(k+" -- > "+v); });
			 */

		});
	}

	public void saveToExcel() {

		List<WebElement> col = dbsPage.getTableColumns();
		List<WebElement> row = dbsPage.getTableRows();
		String path = System.getProperty("user.dir");
		String excelSavePath = path + "/excelData/test.xls";
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("DBS Table");

		for (int i = 1; i <= row.size(); i++) {
			Row excelrow = sheet.createRow(i - 1);
			for (int j = 1; j <= col.size(); j++) {
				WebElement e = dbsPage.getTableCell().findElement(
						By.xpath("//div[@class='rich-text-box']//div//table/tbody/tr[" + i + "]/td[" + j + "]"));

				Cell cell = excelrow.createCell(j - 1);
				cell.setCellValue(e.getText());
			}
		}

		try {
			FileOutputStream out = new FileOutputStream(new File(excelSavePath));
			workbook.write(out);
			out.close();
			System.out.println("Saved Table Data to Excel successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
